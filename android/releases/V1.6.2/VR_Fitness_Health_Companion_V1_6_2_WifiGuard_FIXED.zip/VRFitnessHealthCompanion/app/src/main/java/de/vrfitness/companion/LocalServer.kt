package de.vrfitness.companion

import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets

class LocalServer(
    private val port: Int,
    private val pairingCode: () -> String,
    private val statusProvider: suspend () -> JSONObject,
    private val sessionHandler: suspend (SessionPayload) -> Unit
) {
    private var server: ServerSocket? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun start() {
        if (server != null) return
        server = ServerSocket(port)
        scope.launch {
            while (isActive) {
                val socket = try {
                    server?.accept() ?: break
                } catch (_: Exception) {
                    break
                }
                launch { handle(socket) }
            }
        }
    }

    fun stop() {
        runCatching { server?.close() }
        server = null
        scope.cancel()
    }

    private suspend fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 15000
            val input = BufferedReader(InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8))
            val requestLine = input.readLine() ?: return

            val parts = requestLine.split(" ")
            if (parts.size < 2) {
                respond(s, 400, JSONObject().put("ok", false).put("error", "Bad request"))
                return
            }

            val method = parts[0]
            val path = parts[1]
            var contentLength = 0
            var code = ""

            while (true) {
                val line = input.readLine() ?: break
                if (line.isEmpty()) break
                val idx = line.indexOf(':')
                if (idx > 0) {
                    val key = line.substring(0, idx).trim().lowercase()
                    val value = line.substring(idx + 1).trim()
                    when (key) {
                        "content-length" -> contentLength = value.toIntOrNull() ?: 0
                        "x-vr-fitness-code" -> code = value
                    }
                }
            }

            if (code != pairingCode()) {
                respond(s, 401, JSONObject().put("ok", false).put("error", "Pairing-Code falsch"))
                return
            }

            try {
                when {
                    method == "GET" && path == "/status" -> {
                        respond(s, 200, statusProvider())
                    }

                    method == "POST" && path == "/session" -> {
                        if (contentLength <= 0 || contentLength > 8_000_000) {
                            respond(s, 413, JSONObject().put("ok", false).put("error", "Payload zu groß/leer"))
                            return
                        }

                        val chars = CharArray(contentLength)
                        var read = 0
                        while (read < contentLength) {
                            val n = input.read(chars, read, contentLength - read)
                            if (n <= 0) break
                            read += n
                        }
                        val body = String(chars, 0, read)
                        val payload = PayloadParser.parse(body)
                        sessionHandler(payload)

                        respond(
                            s,
                            200,
                            JSONObject()
                                .put("ok", true)
                                .put("session_id", payload.sessionId)
                        )
                    }

                    else -> respond(
                        s,
                        404,
                        JSONObject().put("ok", false).put("error", "Nicht gefunden")
                    )
                }
            } catch (e: Exception) {
                respond(
                    s,
                    500,
                    JSONObject().put("ok", false).put("error", e.message ?: e.javaClass.simpleName)
                )
            }
        }
    }

    private fun respond(socket: Socket, status: Int, body: JSONObject) {
        val bytes = body.toString().toByteArray(StandardCharsets.UTF_8)
        val text = buildString {
            append("HTTP/1.1 $status ")
            append(if (status in 200..299) "OK" else "ERROR")
            append("\r\n")
            append("Content-Type: application/json; charset=utf-8\r\n")
            append("Content-Length: ${bytes.size}\r\n")
            append("Connection: close\r\n")
            append("\r\n")
        }

        socket.getOutputStream().apply {
            write(text.toByteArray(StandardCharsets.UTF_8))
            write(bytes)
            flush()
        }
    }
}
