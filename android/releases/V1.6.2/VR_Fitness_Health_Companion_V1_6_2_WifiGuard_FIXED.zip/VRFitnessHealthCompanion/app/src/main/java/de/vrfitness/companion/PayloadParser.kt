package de.vrfitness.companion

import org.json.JSONObject

object PayloadParser {
    fun parse(json: String): SessionPayload {
        val obj = JSONObject(json)
        val hrArray = obj.optJSONArray("heart_rate_samples")
        val hr = mutableListOf<HeartRatePoint>()

        if (hrArray != null) {
            for (i in 0 until hrArray.length()) {
                val p = hrArray.getJSONObject(i)
                hr += HeartRatePoint(
                    timestamp = p.getString("timestamp"),
                    bpm = p.getLong("bpm")
                )
            }
        }

        return SessionPayload(
            protocolVersion = obj.optInt("protocol_version", 1),
            sessionId = obj.getString("session_id"),
            sessionName = obj.optString("session_name", "VR Fitness"),
            start = obj.getString("start"),
            end = obj.getString("end"),
            note = obj.optString("note", ""),
            distanceKm = if (obj.isNull("distance_km")) null else obj.optDouble("distance_km"),
            steps = if (obj.isNull("steps")) null else obj.optLong("steps"),
            writeSteps = obj.optBoolean("write_steps", false),
            activeCaloriesKcal = if (obj.isNull("active_calories_kcal")) null else obj.optDouble("active_calories_kcal"),
            calorieEstimateMethod = obj.optString("calorie_estimate_method", "").takeIf { it.isNotBlank() },
            heartRateSamples = hr
        )
    }
}
