package de.vrfitness.companion

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("vrfitness", Context.MODE_PRIVATE)

        if (prefs.getBoolean("background_health_sync", true)) {
            BackgroundSync.schedule(context)
        }

        if (prefs.getBoolean("auto_server", true)) {
            runCatching {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, CompanionService::class.java)
                )
            }.onFailure {
                prefs.edit()
                    .putString("service_status", "autostart fehlgeschlagen")
                    .putString("service_error", it.message ?: it.javaClass.simpleName)
                    .apply()
            }
        }
    }
}
