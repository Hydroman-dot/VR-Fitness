package de.vrfitness.companion

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.text.DateFormat
import java.util.Date

object SyncLogStore {
    private const val FILE_NAME = "health_connect_transfer_log.jsonl"
    private const val MAX_ENTRIES = 100

    private fun file(context: Context): File =
        File(context.filesDir, FILE_NAME)

    @Synchronized
    fun append(
        context: Context,
        payload: SessionPayload,
        success: Boolean,
        error: String? = null
    ) {
        val now = System.currentTimeMillis()
        val obj = JSONObject()
            .put("timestamp_ms", now)
            .put("success", success)
            .put("session_id", payload.sessionId)
            .put("session_name", payload.sessionName)
            .put("start", payload.start)
            .put("end", payload.end)
            .put("distance_km", payload.distanceKm ?: JSONObject.NULL)
            .put("steps", payload.steps ?: JSONObject.NULL)
            .put("write_steps", payload.writeSteps)
            .put("active_calories_kcal", payload.activeCaloriesKcal ?: JSONObject.NULL)
            .put("calorie_estimate_method", payload.calorieEstimateMethod ?: JSONObject.NULL)
            .put("heart_rate_samples", payload.heartRateSamples.size)
            .put("error", error ?: JSONObject.NULL)

        val entries = readRaw(context).toMutableList()
        entries.add(0, obj.toString())
        file(context).writeText(
            entries.take(MAX_ENTRIES).joinToString("\n"),
            Charsets.UTF_8
        )
    }

    @Synchronized
    fun clear(context: Context) {
        runCatching { file(context).delete() }
    }

    @Synchronized
    private fun readRaw(context: Context): List<String> {
        val f = file(context)
        if (!f.exists()) return emptyList()
        return runCatching {
            f.readLines(Charsets.UTF_8).filter { it.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun readDisplay(context: Context): String {
        val lines = readRaw(context)
        if (lines.isEmpty()) return "Noch keine Übertragungen protokolliert."

        return lines.mapNotNull { line ->
            runCatching {
                val obj = JSONObject(line)
                val whenText = DateFormat.getDateTimeInstance(
                    DateFormat.SHORT,
                    DateFormat.MEDIUM
                ).format(Date(obj.optLong("timestamp_ms")))

                val ok = obj.optBoolean("success", false)
                val name = obj.optString("session_name", "VR Fitness")
                val distance = if (obj.isNull("distance_km")) null else obj.optDouble("distance_km")
                val steps = if (obj.isNull("steps")) null else obj.optLong("steps")
                val kcal = if (obj.isNull("active_calories_kcal")) null else obj.optDouble("active_calories_kcal")
                val hrSamples = obj.optInt("heart_rate_samples", 0)
                val writeSteps = obj.optBoolean("write_steps", false)
                val error = if (obj.isNull("error")) null else obj.optString("error")

                buildString {
                    append(if (ok) "✓ " else "✗ ")
                    append(whenText)
                    append(" · ")
                    append(name)

                    if (distance != null) {
                        append("\n  Distanz: ")
                        append(String.format(java.util.Locale.getDefault(), "%.2f km", distance))
                    }
                    if (steps != null) {
                        append(" · Schritte: ")
                        append(steps)
                        append(if (writeSteps) " (geschrieben)" else " (nicht geschrieben)")
                    }
                    if (kcal != null) {
                        append(" · Aktiv: ")
                        append(String.format(java.util.Locale.getDefault(), "%.0f kcal", kcal))
                    }
                    append("\n  Puls-Samples: ")
                    append(hrSamples)

                    if (!error.isNullOrBlank()) {
                        append("\n  Fehler: ")
                        append(error)
                    }
                }
            }.getOrNull()
        }.joinToString("\n\n")
    }
}
