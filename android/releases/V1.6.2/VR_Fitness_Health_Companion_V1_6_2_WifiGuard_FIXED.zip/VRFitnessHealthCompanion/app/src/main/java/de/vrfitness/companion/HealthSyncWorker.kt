package de.vrfitness.companion

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import android.content.Intent
import androidx.core.content.ContextCompat

class HealthSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("vrfitness", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("background_health_sync", true)) return Result.success()

        return try {
            if (prefs.getBoolean("auto_server", true)) {
                val wifiStatus = WifiGuard.status(applicationContext)
                if (wifiStatus.allowed) {
                    runCatching {
                        ContextCompat.startForegroundService(
                            applicationContext,
                            Intent(applicationContext, CompanionService::class.java)
                        )
                    }
                }
            }

            val health = HealthRepository(applicationContext)

            val steps = runCatching { health.readTodaySteps() }.getOrNull()
            val latest = runCatching { health.readLatestHealthValues() }.getOrNull()
            val now = System.currentTimeMillis()

            val edit = prefs.edit()
                .putString("health_sync_status", "ok")
                .remove("health_sync_error")

            if (steps != null) {
                edit.putLong("health_steps_today", steps)
                    .putLong("health_steps_updated_ms", now)
            }

            latest?.weightKg?.let {
                edit.putFloat("health_weight_kg", it.toFloat())
                latest.weightTimeMs?.let { t -> edit.putLong("health_weight_updated_ms", t) }
            }

            latest?.oxygenSaturationPct?.let {
                edit.putFloat("health_spo2_pct", it.toFloat())
                latest.oxygenSaturationTimeMs?.let { t -> edit.putLong("health_spo2_updated_ms", t) }
            }

            edit.apply()
            Result.success()
        } catch (e: SecurityException) {
            prefs.edit()
                .putString("health_sync_status", "berechtigung fehlt")
                .putString("health_sync_error", e.message ?: e.javaClass.simpleName)
                .apply()
            Result.success()
        } catch (e: Exception) {
            prefs.edit()
                .putString("health_sync_status", "fehler")
                .putString("health_sync_error", e.message ?: e.javaClass.simpleName)
                .apply()
            Result.retry()
        }
    }
}
