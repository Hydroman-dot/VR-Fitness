package de.vrfitness.companion

data class HeartRatePoint(
    val timestamp: String,
    val bpm: Long
)

data class SessionPayload(
    val protocolVersion: Int,
    val sessionId: String,
    val sessionName: String,
    val start: String,
    val end: String,
    val note: String,
    val distanceKm: Double?,
    val steps: Long?,
    val writeSteps: Boolean,
    val activeCaloriesKcal: Double?,
    val calorieEstimateMethod: String?,
    val heartRateSamples: List<HeartRatePoint>
)
