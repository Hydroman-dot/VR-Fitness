package de.vrfitness.companion

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import androidx.core.content.ContextCompat

data class WifiGuardStatus(
    val onWifi: Boolean,
    val currentSsid: String?,
    val allowedSsid: String?,
    val allowed: Boolean,
    val reason: String
)

object WifiGuard {
    private fun cleanSsid(value: String?): String? {
        if (value.isNullOrBlank()) return null
        val result = value.trim().removePrefix("\"").removeSuffix("\"")
        if (result.isBlank() || result.equals("<unknown ssid>", ignoreCase = true)) return null
        return result
    }

    fun currentSsid(context: Context): String? {
        val permitted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!permitted) return null

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val active = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(active) ?: return null
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return null

        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return cleanSsid(wifi.connectionInfo?.ssid)
    }

    fun status(context: Context): WifiGuardStatus {
        val prefs = context.getSharedPreferences("vrfitness", Context.MODE_PRIVATE)
        val restrict = prefs.getBoolean("restrict_receiver_to_wifi", true)
        val allowedSsid = cleanSsid(prefs.getString("allowed_wifi_ssid", null))

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val active = cm.activeNetwork
        val caps = active?.let { cm.getNetworkCapabilities(it) }
        val onWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val current = if (onWifi) currentSsid(context) else null

        if (!restrict) {
            return WifiGuardStatus(onWifi, current, allowedSsid, true, "WLAN-Sperre deaktiviert")
        }
        if (!onWifi) {
            return WifiGuardStatus(false, null, allowedSsid, false, "Nicht mit WLAN verbunden")
        }
        if (allowedSsid.isNullOrBlank()) {
            return WifiGuardStatus(true, current, null, false, "Kein freigegebenes WLAN gespeichert")
        }
        if (current.isNullOrBlank()) {
            return WifiGuardStatus(
                true,
                null,
                allowedSsid,
                false,
                "WLAN-Name nicht lesbar – Standortberechtigung prüfen"
            )
        }

        val ok = current == allowedSsid
        return WifiGuardStatus(
            true,
            current,
            allowedSsid,
            ok,
            if (ok) "Freigegebenes WLAN erkannt" else "Anderes WLAN"
        )
    }
}
