package de.vrfitness.companion

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.OxygenSaturationRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.records.metadata.Metadata
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.health.connect.client.units.Energy
import androidx.health.connect.client.units.Length
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

data class LatestHealthValues(
    val weightKg: Double?,
    val weightTimeMs: Long?,
    val oxygenSaturationPct: Double?,
    val oxygenSaturationTimeMs: Long?
)

class HealthRepository(private val context: Context) {

    private val client by lazy { HealthConnectClient.getOrCreate(context) }

    val sessionWritePermissions: Set<String> = setOf(
        HealthPermission.getWritePermission(ExerciseSessionRecord::class),
        HealthPermission.getWritePermission(HeartRateRecord::class),
        HealthPermission.getWritePermission(DistanceRecord::class),
        HealthPermission.getWritePermission(StepsRecord::class),
        HealthPermission.getWritePermission(ActiveCaloriesBurnedRecord::class),
    )

    val readPermissions: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
    )

    val requiredPermissions: Set<String> =
        sessionWritePermissions + readPermissions

    val backgroundReadPermission: String =
        "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND"

    suspend fun grantedPermissions(): Set<String> =
        client.permissionController.getGrantedPermissions()

    suspend fun hasPermissions(): Boolean =
        grantedPermissions().containsAll(sessionWritePermissions)

    suspend fun hasBackgroundReadPermission(): Boolean =
        grantedPermissions().contains(backgroundReadPermission)

    private suspend fun hasReadPermission(permission: String): Boolean =
        grantedPermissions().contains(permission)

    suspend fun readTodaySteps(): Long? {
        val permission = HealthPermission.getReadPermission(StepsRecord::class)
        if (!hasReadPermission(permission)) return null

        val zone = ZoneId.systemDefault()
        val start = LocalDate.now(zone).atStartOfDay(zone).toInstant()
        val end = Instant.now()

        val response = client.aggregate(
            AggregateRequest(
                metrics = setOf(StepsRecord.COUNT_TOTAL),
                timeRangeFilter = TimeRangeFilter.between(start, end)
            )
        )
        return response[StepsRecord.COUNT_TOTAL] ?: 0L
    }

    suspend fun readLatestHealthValues(): LatestHealthValues {
        val granted = grantedPermissions()
        val now = Instant.now()

        var weightKg: Double? = null
        var weightTimeMs: Long? = null
        if (granted.contains(HealthPermission.getReadPermission(WeightRecord::class))) {
            val response = client.readRecords(
                ReadRecordsRequest(
                    recordType = WeightRecord::class,
                    timeRangeFilter = TimeRangeFilter.between(now.minus(30, ChronoUnit.DAYS), now),
                    ascendingOrder = false,
                    pageSize = 1
                )
            )
            response.records.firstOrNull()?.let { record ->
                weightKg = record.weight.inKilograms
                weightTimeMs = record.time.toEpochMilli()
            }
        }

        var spo2: Double? = null
        var spo2TimeMs: Long? = null
        if (granted.contains(HealthPermission.getReadPermission(OxygenSaturationRecord::class))) {
            val response = client.readRecords(
                ReadRecordsRequest(
                    recordType = OxygenSaturationRecord::class,
                    timeRangeFilter = TimeRangeFilter.between(now.minus(30, ChronoUnit.DAYS), now),
                    ascendingOrder = false,
                    pageSize = 1
                )
            )
            response.records.firstOrNull()?.let { record ->
                spo2 = record.percentage.value
                spo2TimeMs = record.time.toEpochMilli()
            }
        }

        return LatestHealthValues(
            weightKg = weightKg,
            weightTimeMs = weightTimeMs,
            oxygenSaturationPct = spo2,
            oxygenSaturationTimeMs = spo2TimeMs
        )
    }

    suspend fun writeSession(payload: SessionPayload) {
        if (!hasPermissions()) {
            throw IllegalStateException("Health-Connect-Schreibberechtigungen fehlen")
        }

        val start = Instant.parse(payload.start)
        val end = Instant.parse(payload.end)
        require(end.isAfter(start)) { "Session-Ende muss nach dem Start liegen" }

        val zone = ZoneId.systemDefault()
        val startOffset = zone.rules.getOffset(start)
        val endOffset = zone.rules.getOffset(end)

        val records = mutableListOf<androidx.health.connect.client.records.Record>()

        val noteParts = mutableListOf<String>()
        if (payload.note.isNotBlank()) noteParts += payload.note
        payload.calorieEstimateMethod?.let {
            noteParts += "Kalorien: Schätzwert ($it)"
        }

        records += ExerciseSessionRecord(
            startTime = start,
            startZoneOffset = startOffset,
            endTime = end,
            endZoneOffset = endOffset,
            exerciseType = ExerciseSessionRecord.EXERCISE_TYPE_RUNNING_TREADMILL,
            title = payload.sessionName.take(120),
            notes = noteParts.joinToString("\n").take(1000).takeIf { it.isNotBlank() },
            metadata = Metadata.manualEntry(
                clientRecordId = "vrfitness-session-${payload.sessionId}"
            )
        )

        val hr = payload.heartRateSamples.mapNotNull { p ->
            runCatching {
                val t = Instant.parse(p.timestamp)
                if (t.isBefore(start) || t.isAfter(end)) return@runCatching null
                if (p.bpm !in 20L..300L) return@runCatching null
                HeartRateRecord.Sample(time = t, beatsPerMinute = p.bpm)
            }.getOrNull()
        }.filterNotNull()

        if (hr.isNotEmpty()) {
            hr.chunked(500).forEachIndexed { index, chunk ->
                val chunkStart = chunk.first().time
                val chunkEndRaw = chunk.last().time
                val chunkEnd = if (chunkEndRaw.isAfter(chunkStart)) chunkEndRaw else chunkStart.plusMillis(1)
                records += HeartRateRecord(
                    startTime = chunkStart,
                    startZoneOffset = zone.rules.getOffset(chunkStart),
                    endTime = chunkEnd,
                    endZoneOffset = zone.rules.getOffset(chunkEnd),
                    samples = chunk,
                    metadata = Metadata.manualEntry(
                        clientRecordId = "vrfitness-hr-${payload.sessionId}-$index"
                    )
                )
            }
        }

        val distanceKm = payload.distanceKm
        if (distanceKm != null && distanceKm > 0.0) {
            records += DistanceRecord(
                startTime = start,
                startZoneOffset = startOffset,
                endTime = end,
                endZoneOffset = endOffset,
                distance = Length.meters(distanceKm * 1000.0),
                metadata = Metadata.manualEntry(
                    clientRecordId = "vrfitness-distance-${payload.sessionId}"
                )
            )
        }

        if (payload.writeSteps && payload.steps != null && payload.steps > 0) {
            records += StepsRecord(
                startTime = start,
                startZoneOffset = startOffset,
                endTime = end,
                endZoneOffset = endOffset,
                count = payload.steps,
                metadata = Metadata.manualEntry(
                    clientRecordId = "vrfitness-steps-${payload.sessionId}"
                )
            )
        }

        val activeKcal = payload.activeCaloriesKcal
        if (activeKcal != null && activeKcal > 0.0 && activeKcal < 10000.0) {
            records += ActiveCaloriesBurnedRecord(
                startTime = start,
                startZoneOffset = startOffset,
                endTime = end,
                endZoneOffset = endOffset,
                energy = Energy.kilocalories(activeKcal),
                metadata = Metadata.manualEntry(
                    clientRecordId = "vrfitness-active-calories-${payload.sessionId}"
                )
            )
        }

        client.insertRecords(records)
    }
}
