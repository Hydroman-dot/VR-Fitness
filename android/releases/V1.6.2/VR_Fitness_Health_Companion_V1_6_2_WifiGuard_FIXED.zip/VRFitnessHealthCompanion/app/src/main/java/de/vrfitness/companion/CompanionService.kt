package de.vrfitness.companion

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import org.json.JSONObject

class CompanionService : Service() {

    companion object {
        const val PORT = 38491
        const val CHANNEL_ID = "vrfitness_companion"
        const val NOTIFICATION_ID = 38491
    }

    private lateinit var server: LocalServer
    private lateinit var health: HealthRepository
    private val wifiHandler = Handler(Looper.getMainLooper())
    private val wifiMonitor = object : Runnable {
        override fun run() {
            val status = WifiGuard.status(applicationContext)
            getSharedPreferences("vrfitness", MODE_PRIVATE)
                .edit()
                .putString("wifi_guard_reason", status.reason)
                .putString("wifi_guard_current_ssid", status.currentSsid ?: "")
                .apply()

            if (!status.allowed) {
                stopSelf()
                return
            }
            wifiHandler.postDelayed(this, 5000)
        }
    }

    override fun onCreate() {
        super.onCreate()

        try {
            health = HealthRepository(applicationContext)
            createNotificationChannel()

            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("VR Fitness Companion")
                .setContentText("PC-Verbindung im lokalen Netzwerk aktiv")
                .setOngoing(true)
                .setSilent(true)
                .build()

            startForeground(NOTIFICATION_ID, notification)

            val prefs = getSharedPreferences("vrfitness", MODE_PRIVATE)

            val wifiStatus = WifiGuard.status(applicationContext)
            prefs.edit()
                .putString("wifi_guard_reason", wifiStatus.reason)
                .putString("wifi_guard_current_ssid", wifiStatus.currentSsid ?: "")
                .apply()

            if (!wifiStatus.allowed) {
                prefs.edit()
                    .putString("service_status", "WLAN gesperrt")
                    .remove("service_error")
                    .apply()
                stopSelf()
                return
            }

            server = LocalServer(
                port = PORT,
                pairingCode = { prefs.getString("pairing_code", "") ?: "" },
                statusProvider = {
                    val steps = prefs.getLong("health_steps_today", -1L)
                    val stepsUpdated = prefs.getLong("health_steps_updated_ms", 0L)
                    val weight = if (prefs.contains("health_weight_kg")) prefs.getFloat("health_weight_kg", 0f).toDouble() else null
                    val weightUpdated = prefs.getLong("health_weight_updated_ms", 0L)
                    val spo2 = if (prefs.contains("health_spo2_pct")) prefs.getFloat("health_spo2_pct", 0f).toDouble() else null
                    val spo2Updated = prefs.getLong("health_spo2_updated_ms", 0L)
                    JSONObject()
                        .put("ok", true)
                        .put("device", android.os.Build.MODEL)
                        .put("companion_version", "1.6.2")
                        .put("health_connect", "bereit")
                        .put("permissions", runCatching { health.hasPermissions() }.getOrDefault(false))
                        .put("background_read", runCatching { health.hasBackgroundReadPermission() }.getOrDefault(false))
                        .put("wifi_guard", WifiGuard.status(applicationContext).allowed)
                        .put("wifi_ssid", WifiGuard.status(applicationContext).currentSsid ?: JSONObject.NULL)
                        .put("wifi_guard_reason", WifiGuard.status(applicationContext).reason)
                        .put("steps_today", if (steps >= 0) steps else JSONObject.NULL)
                        .put("steps_updated_ms", if (stepsUpdated > 0) stepsUpdated else JSONObject.NULL)
                        .put("weight_kg", weight ?: JSONObject.NULL)
                        .put("weight_updated_ms", if (weightUpdated > 0) weightUpdated else JSONObject.NULL)
                        .put("spo2_pct", spo2 ?: JSONObject.NULL)
                        .put("spo2_updated_ms", if (spo2Updated > 0) spo2Updated else JSONObject.NULL)
                        .put("port", PORT)
                },
                sessionHandler = { payload ->
                    try {
                        health.writeSession(payload)
                        SyncLogStore.append(
                            applicationContext,
                            payload,
                            success = true
                        )
                        prefs.edit()
                            .putString("last_session", payload.sessionName)
                            .putLong("last_sync_ms", System.currentTimeMillis())
                            .remove("last_sync_error")
                            .apply()
                    } catch (e: Exception) {
                        SyncLogStore.append(
                            applicationContext,
                            payload,
                            success = false,
                            error = e.message ?: e.javaClass.simpleName
                        )
                        prefs.edit()
                            .putString("last_sync_error", e.message ?: e.javaClass.simpleName)
                            .putLong("last_sync_error_ms", System.currentTimeMillis())
                            .apply()
                        throw e
                    }
                }
            )

            server.start()
            wifiHandler.removeCallbacks(wifiMonitor)
            wifiHandler.postDelayed(wifiMonitor, 5000)
            prefs.edit()
                .putString("service_status", "läuft")
                .remove("service_error")
                .apply()

            BackgroundSync.schedule(applicationContext)

        } catch (e: Exception) {
            getSharedPreferences("vrfitness", MODE_PRIVATE)
                .edit()
                .putString("service_status", "fehler")
                .putString("service_error", e.message ?: e.javaClass.simpleName)
                .apply()
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        wifiHandler.removeCallbacks(wifiMonitor)
        if (::server.isInitialized) runCatching { server.stop() }
        getSharedPreferences("vrfitness", MODE_PRIVATE)
            .edit()
            .putString("service_status", "gestoppt")
            .apply()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "VR Fitness Companion",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}
