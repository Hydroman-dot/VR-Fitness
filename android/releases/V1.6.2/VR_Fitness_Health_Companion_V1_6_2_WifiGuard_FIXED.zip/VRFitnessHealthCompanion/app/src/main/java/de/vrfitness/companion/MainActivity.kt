package de.vrfitness.companion

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.DateFormat
import java.util.Date
import kotlin.random.Random

class MainActivity : ComponentActivity() {

    private lateinit var health: HealthRepository
    private lateinit var status: TextView
    private lateinit var codeView: TextView
    private lateinit var ipView: TextView
    private lateinit var autoServer: CheckBox
    private lateinit var backgroundSync: CheckBox
    private lateinit var transferLog: TextView

    private val healthPermissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) {
        BackgroundSync.schedule(this)
        refreshStatus()
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        health = HealthRepository(this)
        val prefs = getSharedPreferences("vrfitness", MODE_PRIVATE)

        if (prefs.getString("pairing_code", null).isNullOrBlank()) {
            prefs.edit()
                .putString("pairing_code", Random.nextInt(100000, 999999).toString())
                .apply()
        }

        if (!prefs.contains("auto_server")) prefs.edit().putBoolean("auto_server", true).apply()
        if (!prefs.contains("background_health_sync")) prefs.edit().putBoolean("background_health_sync", true).apply()
        if (!prefs.contains("restrict_receiver_to_wifi")) prefs.edit().putBoolean("restrict_receiver_to_wifi", true).apply()

        buildUi()
        requestNotificationPermissionIfNeeded()

        if (prefs.getBoolean("background_health_sync", true)) {
            BackgroundSync.schedule(this)
        }
        if (prefs.getBoolean("auto_server", true)) {
            startCompanionService()
        }

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        if (::transferLog.isInitialized) refreshTransferLog()
    }

    private fun buildUi() {
        val prefs = getSharedPreferences("vrfitness", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 42, 36, 36)
        }

        root.addView(TextView(this).apply {
            text = "VR Fitness Companion"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "Health Connect ↔ VR Fitness PC · V1.6.2"
            textSize = 15f
            setPadding(0, 4, 0, 18)
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 8, 0, 18)
        }
        root.addView(status)

        root.addView(TextView(this).apply {
            text = "PC-Verbindung"
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 12, 0, 8)
        })

        ipView = TextView(this).apply {
            textSize = 18f
            setPadding(0, 4, 0, 4)
        }
        root.addView(ipView)

        codeView = TextView(this).apply {
            textSize = 28f
            gravity = Gravity.CENTER_HORIZONTAL
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 14, 0, 14)
        }
        root.addView(codeView)

        autoServer = CheckBox(this).apply {
            text = "PC-Empfänger automatisch starten"
            isChecked = prefs.getBoolean("auto_server", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("auto_server", checked).apply()
                if (checked) startCompanionService()
            }
        }
        root.addView(autoServer)

        backgroundSync = CheckBox(this).apply {
            text = "Health Connect im Hintergrund aktualisieren"
            isChecked = prefs.getBoolean("background_health_sync", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("background_health_sync", checked).apply()
                if (checked) BackgroundSync.schedule(this@MainActivity)
                else BackgroundSync.cancel(this@MainActivity)
            }
        }
        root.addView(backgroundSync)

        root.addView(TextView(this).apply {
            text = "PC-Empfänger – WLAN"
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 20, 0, 8)
        })

        val restrictWifi = CheckBox(this).apply {
            text = "Nur im freigegebenen WLAN aktiv"
            isChecked = prefs.getBoolean("restrict_receiver_to_wifi", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("restrict_receiver_to_wifi", checked).apply()
                if (checked && !WifiGuard.status(this@MainActivity).allowed) {
                    stopService(Intent(this@MainActivity, CompanionService::class.java))
                } else if (!checked && prefs.getBoolean("auto_server", true)) {
                    startCompanionService()
                }
                refreshStatus()
            }
        }
        root.addView(restrictWifi)

        val allowedWifi = EditText(this).apply {
            hint = "Freigegebene WLAN-SSID"
            setText(prefs.getString("allowed_wifi_ssid", "") ?: "")
        }
        root.addView(allowedWifi)

        val wifiButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        wifiButtons.addView(Button(this).apply {
            text = "Aktuelles WLAN übernehmen"
            setOnClickListener {
                ensureWifiPermission()
                val ssid = WifiGuard.currentSsid(this@MainActivity)
                if (ssid.isNullOrBlank()) {
                    Toast.makeText(
                        this@MainActivity,
                        "WLAN-Name nicht lesbar. Standortberechtigung prüfen.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    allowedWifi.setText(ssid)
                    prefs.edit()
                        .putString("allowed_wifi_ssid", ssid)
                        .putBoolean("restrict_receiver_to_wifi", restrictWifi.isChecked)
                        .apply()
                    Toast.makeText(
                        this@MainActivity,
                        "Freigegebenes WLAN: $ssid",
                        Toast.LENGTH_SHORT
                    ).show()
                    if (prefs.getBoolean("auto_server", true)) startCompanionService()
                    refreshStatus()
                }
            }
        })

        wifiButtons.addView(Button(this).apply {
            text = "WLAN speichern"
            setOnClickListener {
                prefs.edit()
                    .putString("allowed_wifi_ssid", allowedWifi.text.toString().trim())
                    .putBoolean("restrict_receiver_to_wifi", restrictWifi.isChecked)
                    .apply()
                if (prefs.getBoolean("auto_server", true)) startCompanionService()
                refreshStatus()
            }
        })

        root.addView(wifiButtons)

        root.addView(Button(this).apply {
            text = "Health-Connect-Berechtigungen erteilen"
            setOnClickListener {
                val permissions = health.requiredPermissions + health.backgroundReadPermission
                healthPermissionLauncher.launch(permissions)
            }
        })

        root.addView(Button(this).apply {
            text = "PC-Empfänger jetzt starten"
            setOnClickListener {
                startCompanionService()
                Toast.makeText(
                    this@MainActivity,
                    "Companion-Server wird gestartet",
                    Toast.LENGTH_SHORT
                ).show()
                status.postDelayed({ refreshStatus() }, 800)
            }
        })

        root.addView(Button(this).apply {
            text = "Neuen Pairing-Code erzeugen"
            setOnClickListener {
                prefs.edit()
                    .putString("pairing_code", Random.nextInt(100000, 999999).toString())
                    .apply()
                refreshStatus()
            }
        })

        root.addView(TextView(this).apply {
            text = "Nach der Ersteinrichtung kann die App im Hintergrund bleiben. " +
                    "Der PC-Empfänger wird automatisch gestartet und nach einem Handy-Neustart wiederhergestellt, " +
                    "solange die Option aktiviert ist."
            setPadding(0, 24, 0, 16)
        })

        root.addView(TextView(this).apply {
            text = "Health-Connect-Übertragungslog"
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 14, 0, 8)
        })

        val logButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        logButtons.addView(Button(this).apply {
            text = "Log aktualisieren"
            setOnClickListener { refreshTransferLog() }
        })

        logButtons.addView(Button(this).apply {
            text = "Log löschen"
            setOnClickListener {
                SyncLogStore.clear(this@MainActivity)
                refreshTransferLog()
                Toast.makeText(
                    this@MainActivity,
                    "Übertragungslog gelöscht",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        root.addView(logButtons)

        transferLog = TextView(this).apply {
            textSize = 14f
            setPadding(12, 10, 12, 20)
            setTextIsSelectable(true)
        }

        val logScroll = ScrollView(this).apply {
            isFillViewport = false
            addView(
                transferLog,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        root.addView(
            logScroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                620
            )
        )

        val pageScroll = ScrollView(this).apply {
            isFillViewport = true
            addView(
                root,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        setContentView(pageScroll)
        refreshTransferLog()
    }

    private fun refreshStatus() {
        val prefs = getSharedPreferences("vrfitness", MODE_PRIVATE)
        codeView.text = "Pairing-Code: ${prefs.getString("pairing_code", "------")}"
        ipView.text = "IP: ${localIpv4() ?: "nicht gefunden"}:${CompanionService.PORT}"

        lifecycleScope.launch {
            val sdkStatus = HealthConnectClient.getSdkStatus(this@MainActivity)
            val available = sdkStatus == HealthConnectClient.SDK_AVAILABLE
            val permissions = if (available) runCatching { health.hasPermissions() }.getOrDefault(false) else false
            val backgroundPermission = if (available) runCatching { health.hasBackgroundReadPermission() }.getOrDefault(false) else false

            val serviceStatus = prefs.getString("service_status", "nicht gestartet")
            val serviceError = prefs.getString("service_error", null)
            val steps = prefs.getLong("health_steps_today", -1L)
            val stepsUpdated = prefs.getLong("health_steps_updated_ms", 0L)
            val weight = if (prefs.contains("health_weight_kg")) prefs.getFloat("health_weight_kg", 0f) else null
            val weightUpdated = prefs.getLong("health_weight_updated_ms", 0L)
            val spo2 = if (prefs.contains("health_spo2_pct")) prefs.getFloat("health_spo2_pct", 0f) else null
            val spo2Updated = prefs.getLong("health_spo2_updated_ms", 0L)

            status.text = buildString {
                append("Health Connect: ")
                append(if (available) "verfügbar" else "nicht verfügbar")
                append("\nBerechtigungen: ")
                append(if (permissions) "✓ erteilt" else "✗ fehlen")
                append("\nHintergrund-Lesen: ")
                append(if (backgroundPermission) "✓ erlaubt" else "– nicht erlaubt")
                append("\nLokaler Server: ")
                append(serviceStatus)
                append(" · Port ${CompanionService.PORT}")
                append("\nSchritte heute: ")
                append(if (steps >= 0) steps else "--")
                if (stepsUpdated > 0) {
                    append(" · Stand ")
                    append(DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(stepsUpdated)))
                }
                if (weight != null && weight > 0f) {
                    append("\nGewicht: ")
                    append(String.format(java.util.Locale.getDefault(), "%.1f kg", weight))
                    if (weightUpdated > 0) {
                        append(" · Stand ")
                        append(DateFormat.getDateInstance(DateFormat.SHORT).format(Date(weightUpdated)))
                    }
                }
                if (spo2 != null && spo2 > 0f) {
                    append("\nSpO₂: ")
                    append(String.format(java.util.Locale.getDefault(), "%.1f %%", spo2))
                    if (spo2Updated > 0) {
                        append(" · Stand ")
                        append(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(spo2Updated)))
                    }
                }
                val wifiStatus = WifiGuard.status(this@MainActivity)
                append("\nPC-Empfänger WLAN: ")
                append(if (wifiStatus.allowed) "freigegeben" else "gesperrt")
                append(" · ")
                append(wifiStatus.reason)
                wifiStatus.currentSsid?.let {
                    append("\nAktuelles WLAN: ")
                    append(it)
                }
                wifiStatus.allowedSsid?.let {
                    append("\nFreigegebenes WLAN: ")
                    append(it)
                }

                if (!serviceError.isNullOrBlank()) {
                    append("\nServer-Fehler: ")
                    append(serviceError)
                }
            }
        }
    }

    private fun ensureWifiPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                501
            )
        }
    }

    private fun refreshTransferLog() {
        if (!::transferLog.isInitialized) return
        transferLog.text = SyncLogStore.readDisplay(this)
    }

    private fun localIpv4(): String? {
        return try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull {
                    !it.isLoopbackAddress &&
                    it is Inet4Address &&
                    it.isSiteLocalAddress
                }?.hostAddress
        } catch (_: Exception) {
            null
        }
    }

    private fun startCompanionService() {
        try {
            val wifiStatus = WifiGuard.status(this)
        if (!wifiStatus.allowed) {
            getSharedPreferences("vrfitness", MODE_PRIVATE)
                .edit()
                .putString("service_status", "WLAN gesperrt")
                .putString("wifi_guard_reason", wifiStatus.reason)
                .apply()
            refreshStatus()
            return
        }

        ContextCompat.startForegroundService(
                this,
                Intent(this, CompanionService::class.java)
            )
        } catch (e: Exception) {
            getSharedPreferences("vrfitness", MODE_PRIVATE)
                .edit()
                .putString("service_status", "fehler")
                .putString("service_error", e.message ?: e.javaClass.simpleName)
                .apply()

            Toast.makeText(
                this,
                "Server konnte nicht gestartet werden: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
            refreshStatus()
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
