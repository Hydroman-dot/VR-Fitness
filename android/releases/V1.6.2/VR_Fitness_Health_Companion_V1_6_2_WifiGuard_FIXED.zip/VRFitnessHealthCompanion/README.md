# VR Fitness Health Companion V1.6.1

Android companion for VR Fitness.

## V1.6
- reads today's steps from Health Connect
- reads the latest available body weight from Health Connect
- reads the latest available blood oxygen saturation (SpO₂) from Health Connect
- exposes steps, weight and SpO₂ through the local `/status` endpoint
- writes completed VR Fitness sessions to Health Connect
- writes heart-rate samples, distance and optionally steps
- writes estimated active calories when the PC app supplies a value
- background refresh through WorkManager
- local pairing code and foreground PC receiver

## Privacy / data flow
Health data remains local between the PC, this Android companion and Health Connect. The LAN server requires the pairing code.

## Important
Calories written by VR Fitness are estimates and are marked as such in the session metadata. SpO₂ is only displayed when Health Connect already contains a measurement from a compatible source.

## Transfer log
V1.6.1 includes a local Health Connect transfer log. It records whether each VR Fitness session was successfully written to Health Connect and lists the transmitted distance, optional steps, estimated active calories, and heart-rate sample count. Failed writes include the returned error message.
