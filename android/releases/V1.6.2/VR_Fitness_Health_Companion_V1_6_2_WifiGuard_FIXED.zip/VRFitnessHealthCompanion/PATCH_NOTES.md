# Android Companion V1.6.2 – Patch Notes

## Deutsch

### Neu in V1.6.2
- PC-Empfänger standardmäßig nur im freigegebenen WLAN aktiv.
- Aktuelles WLAN kann direkt als erlaubte SSID gespeichert werden.
- Beim Verlassen des WLANs beendet sich der lokale PC-Empfänger automatisch.
- Fremdes WLAN, Mobilfunk oder kein WLAN: PC-Empfänger bleibt aus.
- Hintergrund-Worker kann den Empfänger wieder starten, sobald das erlaubte WLAN zurück ist.
- Health Connect selbst bleibt davon unabhängig aktiv.
- WLAN-Status und Sperrgrund werden in der App angezeigt.
- Übertragungslog aus V1.6.1 bleibt erhalten.


### Neu in V1.6.1
- Sichtbares **Health-Connect-Übertragungslog** direkt in der Android-App.
- Zeigt pro Session Erfolg/Fehler, Sessionname, Distanz, Schritte, aktive kcal und Anzahl übertragener Puls-Samples.
- Fehlgeschlagene Health-Connect-Schreibvorgänge werden inklusive Fehlermeldung protokolliert.
- Log kann in der App aktualisiert und gelöscht werden.
- Bis zu 100 Einträge werden lokal auf dem Gerät gespeichert.


### Neu
- Health Connect: aktuelles Gewicht lesen.
- Health Connect: letzten verfügbaren SpO₂-Wert lesen.
- `/status` liefert jetzt Schritte, Gewicht, SpO₂ und Zeitstempel.
- VR-Fitness-Sessions können geschätzte **aktive Kalorien** als `ActiveCaloriesBurnedRecord` schreiben.
- Herzfrequenz, Distanz, Schritte und Trainingssession bleiben Bestandteil der Synchronisierung.

### Hinweise
- SpO₂ und Gewicht werden nur angezeigt, wenn Health Connect passende Daten und Berechtigungen bereitstellt.
- Kalorien sind ein **Schätzwert**, kein medizinischer Messwert.
- Die App fordert zusätzliche Health-Connect-Berechtigungen für Gewicht, Sauerstoffsättigung und aktive Kalorien an.
- Vor Veröffentlichung bitte in Android Studio kompilieren und auf einem echten Gerät testen.

---

## English

### New in V1.6.2
- PC receiver is restricted to the approved Wi-Fi network by default.
- The current Wi-Fi can be saved directly as the approved SSID.
- The local PC receiver stops automatically when that Wi-Fi is left.
- Other Wi-Fi, mobile data or no Wi-Fi: receiver stays off.
- Background worker can restart the receiver after the approved Wi-Fi returns.
- Health Connect background functions remain independent.
- Wi-Fi status and block reason are shown in the app.
- V1.6.1 transfer log remains included.


### New in V1.6.1
- Visible **Health Connect transfer log** directly in the Android app.
- Shows success/failure, session name, distance, steps, active kcal and heart-rate sample count for each session.
- Failed Health Connect writes are logged with their error message.
- The log can be refreshed and cleared in the app.
- Up to 100 entries are stored locally on the device.


### New
- Reads the latest body weight from Health Connect.
- Reads the latest available SpO₂ value from Health Connect.
- `/status` now returns steps, weight, SpO₂ and timestamps.
- VR Fitness sessions can write estimated **active calories** as `ActiveCaloriesBurnedRecord`.
- Heart rate, distance, steps and the exercise session remain part of synchronization.

### Notes
- Weight and SpO₂ are only shown when Health Connect contains the data and permissions are granted.
- Calories are an **estimate**, not a medical measurement.
- Additional Health Connect permissions are requested for weight, oxygen saturation and active calories.
- Compile in Android Studio and test on a real device before release.
